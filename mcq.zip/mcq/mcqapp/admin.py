# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin
from .models import Questions, QuestionChoice ,UserQuestion
# Register your models here.


admin.site.register(Questions)
admin.site.register(QuestionChoice)

admin.site.register(UserQuestion)