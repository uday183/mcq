# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from django.contrib.auth.models import User
# Create your models here.

class Questions(models.Model):
    q_name = models.CharField(max_length=200)

    def __str__(self):
        return self.q_name

class QuestionChoice(models.Model):
    q = models.ForeignKey(Questions,on_delete=models.CASCADE)
    choice1 = models.CharField(max_length=100)
    choice2 = models.CharField(max_length=100)
    choice3 = models.CharField(max_length=100)
    choice4 = models.CharField(max_length=100)
    user_ans = models.CharField(max_length=100)
    right_ans = models.CharField(max_length=100)
    def __str__(self):
        return self.right_ans



class UserQuestion(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE,)
    user_question = models.ForeignKey(QuestionChoice,on_delete=models.CASCADE,)


