# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from .models import UserQuestion as uq, QuestionChoice
from rest_framework import permissions
# Create your views here.



class UserQuestion(APIView):
    permission_classes = [permissions.IsAuthenticatedOrReadOnly,IsOwnerOrReadOnly]
    def get(self,request):
        #import ipdb;ipdb.set_trace()
        usr_qns_obj = uq.objects.all()
        if not usr_qns_obj.exists():
            return Response({"status":False,"message":"no data"})
        result = []
        for each in usr_qns_obj:
            d={}
            d['id'] = each.id
            d['question_name'] = each.user_question.q.q_name
            d['choice1'] = each.user_question.choice1
            d['choice2'] = each.user_question.choice2
            d['choice3'] = each.user_question.choice3
            d['choice4'] = each.user_question.choice4
            result.append(d)
        return Response(result)
    

    def post(self,request):
        #import ipdb;ipdb.set_trace()
        q_id = request.data.get('q_id')
        user_ans = request.data.get('usr_ans')
        QuestionChoice.objects.filter(q=q_id).update(user_ans=user_ans)
        return Response("updated")


class Results(APIView):
    def get(self,request):
        user_id = request.GET.get('usr_id')
        user_obj = uq.objects.filter(user=user_id)
        if not user_obj.exists():
            return Response({"status":False,"message":"no data"})
        result = []
        
        for each in user_obj:
            # import ipdb;ipdb.set_trace()
            d={}
            user_ans =each.user_question.user_ans
            right_ans = each.user_question.right_ans
            count =0
            if user_ans == right_ans:
                count+=1
            else:
                count -=1
            if count < 0:
                res = 'fail'
            else:
                res= 'pass'
            d['result']=res
            result.append(d)
        return Response(result)
